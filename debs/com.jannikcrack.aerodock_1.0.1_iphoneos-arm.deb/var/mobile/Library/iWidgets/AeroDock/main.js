/* Copyright © Jannik (@JannikCrack) 2019 */
var widget = document.getElementById("widget");

function mainUpdate(type) {
    widget.style.borderRadius = borderradius + "px";
    widget.style.width = widgetwidth + "px";
    widget.style.height = widgetheight + "px";

    if (shadow == 0){
         widget.style.boxShadow = "0px 3px 10px rgba(0,0,0,0.25)"
    }else{
         widget.style.boxShadow= "0px 0px 0px rgba(0,0,0,0.0)"
    }
}