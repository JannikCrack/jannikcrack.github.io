function openFacebook() {
    window.location = 'xeninfo:openapp:com.facebook.Facebook';
}

function openTwitter() {
    window.location = 'xeninfo:openapp:com.atebits.Tweetie2';
}

function openInstagram() {
    window.location = 'xeninfo:openapp:com.burbn.instagram';
}

function openSpotify() {
    window.location = 'xeninfo:openapp:com.spotify.client';
}